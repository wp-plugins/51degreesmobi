<?php
$_SESSION['NO_SWITCH'] = true;
header("Location: get_home_url()");
?>