<?php
$_SESSION['NO_SWITCH'] = true;
header("Location: /index.php");
?>