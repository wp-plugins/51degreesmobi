<div class="spacer"></div>  
</div><!-- content -->  
<?php get_sidebar(); ?>  