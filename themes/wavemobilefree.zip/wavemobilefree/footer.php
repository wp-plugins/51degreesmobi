<div class="spacer"></div>
        <footer id="footer">  
                Copyright © 2012 Wave Mobile by <a href="http://www.wave-digital.co.uk">Wave Mobile</a>
                <p>
                <a href="<?php echo get_template_directory_uri(); ?>/desktop-version.php" class="desktop-version">Switch to Desktop Version</a>
                </p>
        </footer>  
    </div><!-- wrapper -->
    <?php get_sidebar("banner"); ?>
    <?php wp_footer(); ?>
    </body>  
</html>  