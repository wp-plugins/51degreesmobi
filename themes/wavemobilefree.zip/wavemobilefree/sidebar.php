<aside id="sidebar" class="clearfix">  

            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?> 
            
        <?php endif; ?>  
            
</aside><!-- sidebar -->  
<?php get_footer(); ?>